﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for ServicosAdd.xaml
    /// </summary>
    public partial class ServicosAdd : Window
    {
        public ServicosAdd()
        {
            InitializeComponent();
        }

        private void imgSelect_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.ShowDialog();

            if (!dlg.FileName.Equals(null))
            {
                MessageBox.Show(dlg.FileName);
            }
        }
    }
}
