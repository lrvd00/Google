﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        FuncionariosAdd funcionariosWindow = new FuncionariosAdd();
        UsuariosAdd usuariosWindow = new UsuariosAdd();
        AppAdd appWindow = new AppAdd();
        CargoAdd cargoWindow = new CargoAdd();
        ServicosAdd servicosWindow = new ServicosAdd();
        UnidadeAdd unidadeWindow = new UnidadeAdd();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void funcionariosBtn_Click(object sender, RoutedEventArgs e)
        {
            funcionariosWindow.Show();
        }

        private void usuariosBtn_Click(object sender, RoutedEventArgs e)
        {
            usuariosWindow.Show();
        }

        private void appBtn_Click(object sender, RoutedEventArgs e)
        {
            appWindow.Show();
        }

        private void cargoBtn_Click(object sender, RoutedEventArgs e)
        {
            cargoWindow.Show();
        }

        private void servicosBtn_Click(object sender, RoutedEventArgs e)
        {
            servicosWindow.Show();
        }

        private void unidadeBtn_Click(object sender, RoutedEventArgs e)
        {
            unidadeWindow.Show();
        }
    }
}
